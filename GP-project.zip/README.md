# Gaussian-Process-based-Model-Predictive-Control
Project for the course "Statistical Learning and Stochastic Control" at University of Stuttgart
